#! /bin/sh
# This script is called from /sbin/netroot

/sbin/nvmf-autoconnect.sh online
exit 0
