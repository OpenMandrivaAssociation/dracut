#!/bin/sh
. /lib/net-lib.sh
wait_for_if_link enx525401123456
