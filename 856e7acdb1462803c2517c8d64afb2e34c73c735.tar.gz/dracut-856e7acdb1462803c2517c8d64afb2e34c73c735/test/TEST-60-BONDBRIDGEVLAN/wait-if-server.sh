#!/bin/sh
. /lib/net-lib.sh
wait_for_if_link enx525401123456
wait_for_if_link enx525401123457
wait_for_if_link enx525401123458
wait_for_if_link enx525401123459
